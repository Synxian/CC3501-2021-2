Cosas que podrían contar como extras:
-Como extra se crearon piezas con forma de estrella de ishtar
-Al oprimir espacio se alternan las piezas que se están utilizando por cada color
-Al oprimir la flecha hacia arriba, se cambian las piezas del lado superior
-Al oprimir la flecha hacia abajo, se cambian las piezas del lado inferior
-También se añadió un fondo de color café